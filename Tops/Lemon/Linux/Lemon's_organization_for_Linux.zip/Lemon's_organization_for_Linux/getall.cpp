#include<bits/stdc++.h>
using namespace std;

signed main(){
	freopen("ls.txt","w",stdout);
	system("ls");
	return 0;
}

